public class Ball {
    public double posX;
    public double posY;
    public double posZ;
    public double velX;
    public double velY;
    public double velZ;

    public Ball(double posX, double posY, double posZ, double velX, double velY, double velZ) {
        this.posX = posX;
        this.posY = posY;
        this.posZ = posZ;
        this.velX = velX;
        this.velY = velY;
        this.velZ = velZ;
    }
}

