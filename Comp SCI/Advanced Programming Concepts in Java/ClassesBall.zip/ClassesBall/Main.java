//Ball Extender
//Nov 16 2023
//Ryan KS
public class Main {
    public static void main(String[] args) {
        Ball ball = new Ball(Math.random() * (100) + 1, Math.random() * (100) + 1, Math.random() * (100) + 1, Math.random() * (10) + 1, Math.random() * (10) + 1, Math.random() * (10) + 1);
        System.out.println("X: " + ball.posX);
        System.out.println("Y: " + ball.posY);
        System.out.println("Z: " + ball.posZ);
        System.out.println("vel X: " + ball.velX);
        System.out.println("vel Y: " + ball.velY);
        System.out.println("vel Z: " + ball.velZ);
    }
}

